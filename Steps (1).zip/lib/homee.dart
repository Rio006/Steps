import 'package:flutter/material.dart';

void main() => runApp(homee());

class homee extends StatelessWidget {
  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      // Application name
      title: 'Flutter Stateful Clicker Counter',
      home: MyHomePage2(title: ' home'),
      theme: ThemeData(
        // Application theme data, you can set the colors for the application as
        // you want
        primarySwatch: Colors.purple,
      ),
    );
  }
}

class MyHomePage2 extends StatefulWidget {
  final String title;
  const MyHomePage2({Key? key, required this.title}) : super(key: key);

  // This widget is the home page of your application. It is stateful, meaning
  // that it has a State object (defined below) that contains fields that affect
  // how it looks.

  // This class is the configuration for the state. It holds the values (in this
  // case the title) provided by the parent (in this case the App widget) and
  // used by the build method of the State. Fields in a Widget subclass are
  // always marked "final".

  @override
  _MyHomePageState2 createState() => _MyHomePageState2();
}

class _MyHomePageState2 extends State<MyHomePage2> {
  int _counter = 0;
  bool checkBox = false;
  bool checkBoxii = false;
  bool checkBoxiii = false;

  void _incrementCounter() {
    setState(() {
      // This call to setState tells the Flutter framework that something has
      // changed in this State, which causes it to rerun the build method below
      // so that the display can reflect the updated values. If we changed
      // _counter without calling setState(), then the build method would not be
      // called again, and so nothing would appear to happen.
      _counter++;
    });
  }

  @override
  Widget build(BuildContext context) {
    // This method is rerun every time setState is called, for instance as done
    // by the _incrementCounter method above.
    //
    // The Flutter framework has been optimized to make rerunning build methods
    // fast, so that you can just rebuild anything that needs updating rather
    // than having to individually change instances of widgets.
    return Scaffold(
      appBar: AppBar(
        // Here we take the value from the MyHomePage object that was created by
        // the App.build method, and use it to set our appbar title.
        title: Text(widget.title),
      ),
      body: Container(
        padding: EdgeInsets.fromLTRB(20, 200, 20, 0),
        decoration: BoxDecoration(
          image: DecorationImage(
            image: AssetImage("images/home.jpg"),
            fit: BoxFit.cover,
          ),
        ),
        // Center is a layout widget. It takes a single child and positions it
        // in the middle of the parent.

        child: Column(
          // Column is also a layout widget. It takes a list of children and
          // arranges them vertically. By default, it sizes itself to fit its
          // children horizontally, and tries to be as tall as its parent.
          //
          // Column has various properties to control how it sizes itself and
          // how it positions its children. Here we use mainAxisAlignment to
          // center the children vertically; the main axis here is the vertical
          // axis because Columns are vertical (the cross axis would be
          // horizontal).
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            Text(
              'All things will be okay, no worries you are in safe, let us relax',
              style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
              textAlign: TextAlign.center,
            ),
            Text(
              '$_counter',
              style: TextStyle(fontSize: 25, fontWeight: FontWeight.bold),
            ),
            RaisedButton(
              onPressed: _incrementCounter,
              shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(50)),
              color: Colors.purple,
              textColor: Colors.white,
              child: Text('Breathe'),
            ),
            Expanded(
              child: ListView(
                padding: EdgeInsets.fromLTRB(20, 25, 20, 0),
                children: [
                  CheckboxListTile(
                    title: Text(
                        'breathe in through your nose and out through your mouth as slowly, deeply and gently '),
                    controlAffinity: ListTileControlAffinity.leading,
                    onChanged: ((bool? valu1) {
                      setState(() {
                        checkBox = valu1!;
                      });
                    }),
                    value: checkBox,
                  ),
                  CheckboxListTile(
                    title: Text('Remember that it will pass.'),
                    controlAffinity: ListTileControlAffinity.leading,
                    onChanged: ((bool? valu2) {
                      setState(() {
                        checkBoxii = valu2!;
                      });
                    }),
                    value: checkBoxii,
                  ),
                  CheckboxListTile(
                    title: Text('Remember a good thing'),
                    controlAffinity: ListTileControlAffinity.leading,
                    onChanged: ((bool? valu3) {
                      setState(() {
                        checkBoxiii = valu3!;
                      });
                    }),
                    value: checkBoxiii,
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );

    // This trailing comma makes auto-formatting nicer for build methods.
  }
}
